﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace WinFormsApp1
{
    internal class DeletePlayerComponent
    {
        MySqlConnection sqlConnection;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        MySqlDataReader sqlDataReader;
        public Button btnDeletePlayer = new Button();
        public Control[] deletePlayerComponent() 
        {

            Label lblTeam = new Label
            {
                Name = "lblTeam",
                Location = new Point(50, 30),
                Size = new Size(90, 30),
                Text = "Team :"
            };
            

            ComboBox comboTeam = new ComboBox
            {
                Name = "comboTeam",
                Location = new Point(140, 30),
                Size = new Size(100, 30),
                DropDownStyle = ComboBoxStyle.DropDownList,
            };
    
            

            DataGridView dgvPlayer = new DataGridView 
            { 
                Name = "dgvPlayer",
                Location = new Point(50, 100),
                Size = new Size(600, 300),
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            };

            //Create Button Delete Player

            btnDeletePlayer.Name = "btnDeletePlayer";
            btnDeletePlayer.Location = new Point(150, 430);
            btnDeletePlayer.Size = new Size(150, 30);
            btnDeletePlayer.Text = "Delete Player";
            
            return new Control[] { lblTeam, comboTeam, dgvPlayer, btnDeletePlayer};
        }

        // You should implement code to fill the ComboBox with the teams,
        // fill the DataGridView with the players of the selected team and 
        // wire up the Button click event to delete the selected player. 
        // This will require SQL queries to your database, and the exact implementation
        // will depend on how your database is structured.
    }
}
