using MySql.Data.MySqlClient;
using System.Data;
using System.IO;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        MySqlConnection sqlConnection;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        MySqlDataReader sqlDataReader;
        DataTable dtPlayer = new DataTable();
        DataTable dtTeam = new DataTable();
        DataTable dtNationality = new DataTable();
        DataTable dtManager = new DataTable();

        AddPlayerComponent addComponentClass = new AddPlayerComponent();
        EditManagerComponent editManagerComponent = new EditManagerComponent();

        public Form1()
        {
            try
            {
                string connection = "server=localhost;user=root;port=3366;pwd=;database=premier_league";
                sqlConnection = new MySqlConnection(connection);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);

            }
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {


        }


        private void updateDatafromDatabase()
        {

            try
            {
                string command = "SELECT player_id, player_name, height, weight,team_name,nation,playing_pos,team_number,birthdate FROM ((premier_league.player p inner join premier_league.team t on p.team_id = t.team_id) inner join premier_league.nationality n on p.nationality_id = n.nationality_id);";
                sqlCommand = new MySqlCommand(command, sqlConnection);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dtPlayer);




                List<string> listTeam = new List<string>();
                List<string> listPos = new List<string>();
                List<string> listNationality = new List<string>();
                foreach (DataRow row in dtPlayer.Rows)
                {
                    listTeam.Add(row[4].ToString());
                    listPos.Add(row[6].ToString());
                    listNationality.Add(row[5].ToString());

                }
                List<string> uniqueListTeam = listTeam.Distinct().ToList();
                List<string> uniqueListPos = listPos.Distinct().ToList();
                List<string> uniqueListNationality = listNationality.Distinct().ToList();
                foreach (string item in uniqueListNationality)
                {
                    if (panel1.Controls[5] is ComboBox comboBox)
                    {

                        comboBox.Items.Add(item);
                    }
                }
                foreach (string item in uniqueListPos)
                {
                    if (panel1.Controls[6] is ComboBox comboBox)
                    {

                        comboBox.Items.Add(item);
                    }
                }
                foreach (string item in uniqueListTeam)
                {
                    if (panel1.Controls[7] is ComboBox comboBox)
                    {

                        comboBox.Items.Add(item);
                    }
                }

            }
            catch (Exception e1)
            {

                MessageBox.Show(e1.Message);
            }
        }
        private void addPlayerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();


            Control[] controlsAddPlayer = addComponentClass.AddComponentPlayer();
            foreach (Control item in controlsAddPlayer)
            {
                panel1.Controls.Add(item);
            }

            addComponentClass.btnAddPlayer.Click += new EventHandler(btnAddPlayer_Click);
            updateDatafromDatabase();
        }


        private void btnAddPlayer_Click(object sender, EventArgs e)
        {

            if (!string.IsNullOrEmpty(panel1.Controls[0].Text) && !string.IsNullOrEmpty(panel1.Controls[1].Text) && !string.IsNullOrEmpty(panel1.Controls[2].Text) && !string.IsNullOrEmpty(panel1.Controls[3].Text) && !string.IsNullOrEmpty(panel1.Controls[4].Text) && !string.IsNullOrEmpty(panel1.Controls[5].Text) && !string.IsNullOrEmpty(panel1.Controls[6].Text) && !string.IsNullOrEmpty(panel1.Controls[7].Text))
            {
                dtTeam.Clear();
                string command2 = $"select team_id from premier_league.team where team_name = '{panel1.Controls[7].Text}'";
                sqlCommand = new MySqlCommand(command2, sqlConnection);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dtTeam);

                //dataGridView1.DataSource= dtTeam;

                dtNationality.Clear();
                string command3 = $"select nationality_id from premier_league.nationality where nation = '{panel1.Controls[5].Text}'";
                sqlCommand = new MySqlCommand(command3, sqlConnection);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dtNationality);

                String dataBirthday = "0000-00-00";
                if (panel1.Controls[17] is DateTimePicker dateTime)
                {
                    dataBirthday = dateTime.Value.Date.ToString("yyyy-MM-dd");
                }

                string command = $"insert into player values('{panel1.Controls[0].Text}','{panel1.Controls[4].Text}','{panel1.Controls[1].Text}','{dtNationality.Rows[0][0].ToString()}','{panel1.Controls[6].Text}','{panel1.Controls[2].Text}','{panel1.Controls[3].Text}','{dataBirthday}','{dtTeam.Rows[0][0].ToString()}',1,0)";
                try
                {
                    sqlConnection.Open();
                    sqlCommand = new MySqlCommand(command, sqlConnection);
                    sqlDataReader = sqlCommand.ExecuteReader();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }
                finally
                {
                    sqlConnection.Close();
                    for (int i = 0; i < 8; i++)
                    {
                        panel1.Controls[i].Text = "";

                    }

                }

            }
            else
            {

                MessageBox.Show("The text is null or empty.");
            }

        }


        private void updateDataComboAtEditManager()
        {
            DataTable dtTeamManager = new DataTable();
            dtManager.Clear();
            try
            {
                string command = "SELECT team_name FROM premier_league.team t;";
                sqlCommand = new MySqlCommand(command, sqlConnection);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dtTeamManager);

                foreach (DataRow row in dtTeamManager.Rows)
                {
                    if (panel1.Controls[1] is ComboBox comboBox)
                    {
                        // Add items to the ComboBox control
                        comboBox.Items.Add(row[0].ToString());
                    }

                }
            }
            catch (Exception e1)
            {

                MessageBox.Show(e1.Message);
            }

            DataTable dtFreeTeamManager = new DataTable();
            dtFreeTeamManager.Clear();
            try
            {
                string command2 = "select b.manager_name,c.nation, b.birthdate\r\nfrom premier_league.manager b  inner join\r\n     premier_league.nationality c on\r\nb.nationality_id = c.nationality_id where\r\nb.working = '0';";
                sqlCommand = new MySqlCommand(command2, sqlConnection);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dtFreeTeamManager);


                if (panel1.Controls[4] is DataGridView dgvFreeTeamManager)
                {
                    // Add items to the ComboBox control
                    dgvFreeTeamManager.DataSource = dtFreeTeamManager;
                }
            }
            catch (Exception e1)
            {

                MessageBox.Show(e1.Message);
            }

        }

        private void ComboTeam_SelectedIndexChanged(object? sender, EventArgs e)
        {
            DataTable dtManager = new DataTable();

            ComboBox clickedCombo = (ComboBox)sender;
            try
            {

                string command = $"select b.manager_name, a.team_name, b.birthdate, c.nation from premier_league.team a inner join premier_league.manager b on a.manager_id = b.manager_id inner join premier_league.nationality c on b.nationality_id = c.nationality_id where a.team_name = '{clickedCombo.Text}';";
                sqlCommand = new MySqlCommand(command, sqlConnection);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dtManager);

                if (panel1.Controls[2] is DataGridView dgvManager)
                {
                    // Add items to the ComboBox control
                    dgvManager.DataSource = dtManager;

                }
            }
            catch (Exception e1)
            {

                MessageBox.Show(e1.Message);
            }
        }

        private String findManagerIDByName(String name)
        {

            String id = "";
            DataTable dtTmp = new DataTable();
            try
            {

                string command = $"select m.manager_id from premier_league.manager m where m.manager_name='{name}';";
                sqlCommand = new MySqlCommand(command, sqlConnection);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dtTmp);
                id = dtTmp.Rows[0][0].ToString();
            }
            catch (Exception e1)
            {

                MessageBox.Show(e1.Message);
            }


            return id;
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (panel1.Controls[2] is DataGridView dgvTeamManager)
            {
                // Add items to the ComboBox control
                //MessageBox.Show(dgvFreeTeamManager.Rows[dgvFreeTeamManager.CurrentCell.RowIndex].Cells[0].Value.ToString());

                try
                {

                    string command = $"UPDATE premier_league.manager m SET m.working = '0' WHERE m.manager_id = '{findManagerIDByName(dgvTeamManager.Rows[dgvTeamManager.CurrentCell.RowIndex].Cells[0].Value.ToString())}';";
                    sqlConnection.Open();
                    sqlCommand = new MySqlCommand(command, sqlConnection);
                    sqlDataReader = sqlCommand.ExecuteReader();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }
                finally
                {
                    sqlConnection.Close();

                }
            }
            if (panel1.Controls[4] is DataGridView dgvFreeTeamManager)
            {
                // Add items to the ComboBox control
                //MessageBox.Show(dgvFreeTeamManager.Rows[dgvFreeTeamManager.CurrentCell.RowIndex].Cells[0].Value.ToString());

                try
                {
                    string command = $"UPDATE premier_league.manager m SET m.working = '1' WHERE m.manager_id = '{findManagerIDByName(dgvFreeTeamManager.Rows[dgvFreeTeamManager.CurrentCell.RowIndex].Cells[0].Value.ToString())}';";
                    sqlConnection.Open();
                    sqlCommand = new MySqlCommand(command, sqlConnection);
                    sqlDataReader = sqlCommand.ExecuteReader();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }
                finally
                {
                    sqlConnection.Close();

                }

                string command2 = $"UPDATE premier_league.team t SET t.manager_id = '{findManagerIDByName(dgvFreeTeamManager.Rows[dgvFreeTeamManager.CurrentCell.RowIndex].Cells[0].Value.ToString())}' WHERE t.team_name = '{panel1.Controls[1].Text}';";
                try
                {
                    sqlConnection.Open();
                    sqlCommand = new MySqlCommand(command2, sqlConnection);
                    sqlDataReader = sqlCommand.ExecuteReader();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }
                finally
                {
                    sqlConnection.Close();

                }
            }
            MessageBox.Show("Data was Edited");
            panel1.Controls[1].Text = "";
            if (panel1.Controls[2] is DataGridView dgvManager)
            {
                dgvManager.Rows.Clear();
            }
            updateDataComboAtEditManager();

        }

        private void btnDeletePlayer_Click(object sender, EventArgs e)
        {
            if (panel1.Controls[2] is DataGridView dgvPlayer)
            {
                int totalPlayers = dgvPlayer.Rows.Count;

                // Only allow a team to remove a player if their total number of players are greater than 11
                if (totalPlayers > 11)
                {
                    try
                    {
                        // Open the connection
                        sqlConnection.Open();

                        // Update the delete status of the chosen player to 0
                        string command = $"UPDATE premier_league.player p SET p.status = '0' WHERE p.player_id = '{findPlayerIDByName(dgvPlayer.Rows[dgvPlayer.CurrentCell.RowIndex].Cells[0].Value.ToString())}';";
                        sqlCommand = new MySqlCommand(command, sqlConnection);
                        sqlCommand.ExecuteNonQuery();

                        MessageBox.Show("Player was removed successfully");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    finally
                    {
                        // Close the connection
                        sqlConnection.Close();

                        // Clear the DataGridView and ComboBox
                        if (dgvPlayer != null)
                        {
                            dgvPlayer.Rows.Clear();
                        }

                        if (panel1.Controls[1] is ComboBox comboTeam)
                        {
                            comboTeam.SelectedIndex = -1;
                        }

                        // Update data
                        updateDataComboAtDeletePlayer();
                    }
                }
                else
                {
                    MessageBox.Show("Cannot delete player. The total number of players must be greater than 11.");
                }
            }
        }

        private string findPlayerIDByName(string playerName)
        {
            string playerId = "";

            try
            {
                // Open the connection
                sqlConnection.Open();

                // Find player id by player name
                string command = "SELECT player_id FROM premier_league.player WHERE player_name = @playerName AND status = '1';";
                sqlCommand = new MySqlCommand(command, sqlConnection);
                sqlCommand.Parameters.AddWithValue("@playerName", playerName);

                // Execute the command
                MySqlDataReader reader = sqlCommand.ExecuteReader();

                // Check if there is any data
                if (reader.Read())
                {
                    playerId = reader["player_id"].ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                // Close the connection
                sqlConnection.Close();
            }

            return playerId;
        }

        private void updateDataComboAtDeletePlayer()
        {
            try
            {
                // Open the connection
                sqlConnection.Open();

                // Fetch the updated data from the database
                string command = "SELECT team_name FROM premier_league.team;";
                sqlCommand = new MySqlCommand(command, sqlConnection);

                // Execute the command
                MySqlDataReader reader = sqlCommand.ExecuteReader();

                if (panel1.Controls[1] is ComboBox comboTeam)
                {
                    comboTeam.Items.Clear();

                    // Fill the ComboBox with updated data
                    while (reader.Read())
                    {
                        comboTeam.Items.Add(reader["team_name"].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                // Close the connection
                sqlConnection.Close();
            }
        }


        private void editManagerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            /*
             * Combo team = 1
                dgvManager = 2
                dgvFreeManager = 4
                btnUpdate = 5
             */

            panel1.Controls.Clear();

            Control[] controlsEditManagerComponent = editManagerComponent.editManagerComponent();
            foreach (Control item in controlsEditManagerComponent)
            {
                panel1.Controls.Add(item);
            }
            updateDataComboAtEditManager();
            if (panel1.Controls[1] is ComboBox comboBox)
            {
                // Add items to the ComboBox control
                comboBox.SelectedIndexChanged += new EventHandler(ComboTeam_SelectedIndexChanged);
            }

            if (panel1.Controls[5] is Button btnEdit)
            {
                // Add items to the ComboBox control
                btnEdit.Click += new EventHandler(btnEdit_Click);
            }


        }

        private void removePlayerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();

            // Instance of the DeletePlayerComponent class
            DeletePlayerComponent deletePlayerComponentClass = new DeletePlayerComponent();

            // Get Controls from DeletePlayerComponent
            Control[] controlsDeletePlayer = deletePlayerComponentClass.deletePlayerComponent();

            foreach (Control item in controlsDeletePlayer)
            {
                panel1.Controls.Add(item);
            }

            deletePlayerComponentClass.btnDeletePlayer.Click += new EventHandler(btnDeletePlayer_Click);

            // call the function to update data from the database
            updateDatafromDatabase();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
    }
}